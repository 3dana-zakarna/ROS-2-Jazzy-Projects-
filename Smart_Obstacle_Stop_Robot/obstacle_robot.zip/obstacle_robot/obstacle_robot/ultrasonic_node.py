
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32, String


class UltrasonicNode(Node):

    def __init__(self):
        super().__init__('ultrasonic_node')

        # Current distance in centimeters
        self.distance = 100.0

        # Motor starts ON
        self.motor_on = True

        # Publisher: sends distance
        self.publisher = self.create_publisher(
            Float32,
            '/distance',
            10
        )

        # Subscriber: receives motor commands
        self.subscription = self.create_subscription(
            String,
            '/motor_cmd',
            self.motor_callback,
            10
        )

        # Timer: runs every 0.5 seconds
        self.timer = self.create_timer(
            0.5,
            self.publish_distance
        )

        self.get_logger().info('Ultrasonic node started')

    def motor_callback(self, msg):

        if msg.data == 'GO' or msg.data == 'SLOW':
            self.motor_on = True

        elif msg.data == 'STOP':
            self.motor_on = False

    def publish_distance(self):

        msg = Float32()
        msg.data = float(self.distance)

        self.publisher.publish(msg)

        if self.motor_on:
            self.distance -= 5.0


def main(args=None):

    rclpy.init(args=args)

    node = UltrasonicNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
