
import rclpy
from rclpy.node import Node
from std_msgs.msg import String


class MotorNode(Node):

    def __init__(self):
        super().__init__('motor_node')

        # Initial motor state
        self.motor_state = None

        # Subscriber: receives motor commands
        self.subscription = self.create_subscription(
            String,
            '/motor_cmd',
            self.motor_callback,
            10
        )

    def motor_callback(self, msg):

        # Determine the new motor state
        if msg.data == 'GO' or msg.data == 'SLOW':
            new_state = True

        elif msg.data == 'STOP':
            new_state = False

        else:
            return

        # Log only when the state changes
        if new_state != self.motor_state:

            self.motor_state = new_state

            if self.motor_state:
                self.get_logger().info('Motor: ON')

            else:
                self.get_logger().info('Motor: OFF')


def main(args=None):

    rclpy.init(args=args)

    node = MotorNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
