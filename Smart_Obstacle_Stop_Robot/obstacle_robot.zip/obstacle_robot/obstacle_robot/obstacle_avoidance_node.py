
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32, String


class ObstacleAvoidanceNode(Node):

    def __init__(self):
        super().__init__('obstacle_avoidance_node')

        # Publisher: sends motor commands
        self.publisher = self.create_publisher(
            String,
            '/motor_cmd',
            10
        )

        # Subscriber: receives distance readings
        self.subscription = self.create_subscription(
            Float32,
            '/distance',
            self.distance_callback,
            10
        )

        self.get_logger().info('Obstacle avoidance node started')

    def distance_callback(self, msg):

        distance = msg.data

        # Decide the motor command
        if distance >= 40.0:
            command = 'GO'

        elif distance >= 20.0:
            command = 'SLOW'

        else:
            command = 'STOP'

        # Create and publish the command
        motor_msg = String()
        motor_msg.data = command

        self.publisher.publish(motor_msg)

        # Log distance and command
        self.get_logger().info(
            f'Distance: {distance:.1f} cm -> {command}'
        )


def main(args=None):

    rclpy.init(args=args)

    node = ObstacleAvoidanceNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
