
from setuptools import find_packages, setup

package_name = 'obstacle_robot'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Dana',
    maintainer_email='zakdana3@gmail.com',
    description='Smart Obstacle Stop Robot',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'ultrasonic_node = obstacle_robot.ultrasonic_node:main',
            'obstacle_avoidance_node = obstacle_robot.obstacle_avoidance_node:main',
            'motor_node = obstacle_robot.motor_node:main',
        ],
    },
)
